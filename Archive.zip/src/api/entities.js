import { base44 } from './base44Client';


export const Sound = base44.entities.Sound;

export const SoundStats = base44.entities.SoundStats;



// auth sdk:
export const User = base44.auth;