export const AD_IDS = {
  LEFT: 'left-side-ad-' + Math.random().toString(36).substring(2, 9),
  RIGHT: 'right-side-ad-' + Math.random().toString(36).substring(2, 9),
  BOTTOM: 'bottom-fixed-ad-' + Math.random().toString(36).substring(2, 9)
};
